package br.com.walmart.dashboard.robot.task;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Date;

import br.com.walmart.dashboard.robot.exception.RobotException;
import br.com.walmart.dashboard.robot.util.PropertyHandler;

import com.healthmarketscience.jackcess.CursorBuilder;
import com.healthmarketscience.jackcess.Database;
import com.healthmarketscience.jackcess.DatabaseBuilder;
import com.healthmarketscience.jackcess.Row;
import com.healthmarketscience.jackcess.Table;

public class EmersonTask extends GenericTask {

	private final String FANTASIA = "emerson";
	private String config;
	
	public EmersonTask(String config) throws RobotException {
		setFantasia(FANTASIA);
		setFornecedor(FANTASIA);
		this.config = config;
	}

	@Override
	public String call() throws Exception {
		// log(logger, INFO, "Opening the Access file");
		Database database = null;

		try {
			database = DatabaseBuilder.open(new File(PropertyHandler
					.getInstance().getValue(config)));
		} catch (IOException ioe) {
			closeMainConnection();
			throw new RobotException(String.format(
					"MS Access file %s no readable or no exists",
					PropertyHandler.getInstance().getValue(config)));
		}

		Table alarmTable = database.getTable("Alarm");
		if (alarmTable == null) {
			database.close();
			closeMainConnection();
			throw new RobotException("Alarm table no readable or no exists");
		}

		for (Row alarmRow : alarmTable) {
			Long currentNum = Long.parseLong(alarmRow.get("Num").toString());
			//--------------------------02082018-------------------------------------
			Date occurenceTimeStamp = (Date) alarmRow.get("Occurance Timestamp");
						
			LocalDateTime data1 = LocalDateTime.ofInstant(
				Instant.ofEpochMilli(occurenceTimeStamp.getTime()),
				ZoneOffset.systemDefault());
			//-----------------------------------------------------------------------
			Date receivedTimestamp = (Date) alarmRow.get("ReceivedTimestamp");
			if (!validField(receivedTimestamp, "Alarm[ReceivedTimestamp]",
					currentNum)) {
				continue;
			}

			LocalDateTime data2 = LocalDateTime.now();
			Duration duration = Duration.between(data1, data2);

			String h = PropertyHandler.getInstance().getValue("ALARM_DURATION");
			if (h == null || "".equals(h)) {
				h = "1";
			}

			if (Long.parseLong(h) < duration.toHours()) {
				continue;
			}

			Date dataDoAlarme = (Date) alarmRow.get("Occurance Timestamp");
			if (!validField(dataDoAlarme, "Alarm[Occurance Timestamp]",
					currentNum)) {
				continue;
			}

			Integer siteNum = (Integer) alarmRow.get("Site Num");
			if (!validField(siteNum, "Alarm[Site Num]", currentNum)) {
				continue;
			}

			String alarmName = (String) alarmRow.get("AlarmText");
			if (alarmName == null || "".equals(alarmName)) {
				alarmName = "Alarme não cadastrado";
			}

			String circuito = (String) alarmRow.get("CellName");

			String tipoDoRack = (String) alarmRow.get("PropName");

			Table siteTable = database.getTable("Site");
			if (siteTable == null) {
				database.close();
				closeMainConnection();
				throw new RobotException("Site table no readable or no exists");
			}

			// log(logger, INFO, String.format(
			// "Filtering the Site Table where Num = %d", siteNum));
			Row siteRow = CursorBuilder.findRow(siteTable,
					Collections.singletonMap("Num", siteNum));

			String unitName = null;
			String unitNameOriginal = null;

			if (siteRow != null) {
				// log(logger, INFO, "Getting the site name");
				unitName = (String) siteRow.get("Name");
				unitNameOriginal = (String) siteRow.get("Name");

				if (unitName == null) {
					// Force to 99999
					unitName = "99999";
				}

				if (!unitName.isEmpty()) {
					String[] split = unitName.split(" ");
					unitName = split[0];
				}
			} else {
				// Force to 99999
				unitName = "99999";
			}

			if ("".equals(unitName)) {
				String title = "There was error when get 'Codigo legado'";
				String description = String.format(
						"Unit's code is blank to Emerson's alert #%d",
						currentNum);
				logAndSendEmail(title, description);
				continue;
			}
			
			Integer codUnidade = null;
			
			try {
				codUnidade = getCodUnidade(unitName);
			} catch (RobotException e) {
				continue;
			}
			
			atualizarDataUltimoEnvioUnidade(codUnidade);
			
			if (checkIfAlarmHasAlreadyBeenInserted(alarmName, unitNameOriginal,
					circuito, tipoDoRack)) {
				continue;
			}

			Integer alertaPadrao = null;

			try {
				alertaPadrao = getDefaultAlertMessage(alarmName);
			} catch (RobotException e) {
				continue;
			}

		

			Integer statusAlerta = getSemaforo(alertaPadrao);

			if (statusAlerta == null) {
				statusAlerta = 0;
			}

			try {
				insertAlertaControlador(alarmName, alertaPadrao, codUnidade,
						statusAlerta, dataDoAlarme, currentNum, circuito,
						tipoDoRack, unitNameOriginal,null);
			} catch (RobotException e) {
				String title = "There was error when inserting the 'AlertaControlador' table";
				String description = e.getMessage();
				logAndSendEmail(title, description);
			}

		}

		// log(logger, INFO, "Closing the Access file");
		database.close();
		closeMainConnection();

		return FANTASIA;
	}

}
