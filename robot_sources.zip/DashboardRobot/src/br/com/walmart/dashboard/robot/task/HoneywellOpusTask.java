package br.com.walmart.dashboard.robot.task;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import br.com.walmart.dashboard.robot.exception.RobotException;
import br.com.walmart.dashboard.robot.util.PropertyHandler;
import br.com.walmart.encrypter.Encrypter;

public class HoneywellOpusTask extends GenericTask {

	private final String FANTASIA = "honeywell-opus";

	public HoneywellOpusTask() throws RobotException {
		setFantasia(FANTASIA);
		setFornecedor("honeywell");
	}

	public String call() throws Exception {

		Connection connection = null;

		String driver = null;
		String url = null;
		String user = null;
		String pwd = null;

		if (connection == null || (connection != null && connection.isClosed())) {

			driver = PropertyHandler.getInstance().getValue(
					"HONEYWELL_OPUS_MSSQL_DRIVER");
			url = PropertyHandler.getInstance().getValue(
					"HONEYWELL_OPUS_MSSQL_URL");
			user = PropertyHandler.getInstance().getValue(
					"HONEYWELL_OPUS_MSSQL_USER");
			pwd = new Encrypter().decrypt(PropertyHandler.getInstance()
					.getValue("HONEYWELL_OPUS_MSSQL_PWD"));

			try {
				Class.forName(driver);
				connection = DriverManager.getConnection(url, user, pwd);
			} catch (SQLException sqle) {
				closeMainConnection();

				String title = String
						.format("There was error when connect to Honeywell Opus' MSSQL Server.");
				String description = sqle.toString();

				throw new Exception(title + "- " + description);
			}
		}

		StringBuilder sql = null;
		PreparedStatement ps = null;
		ResultSet rsLoop = null;

		try {
			String h = PropertyHandler.getInstance().getValue("ALARM_DURATION");
			if (h == null || "".equals(h)) {
				h = "1";
			}

			sql = new StringBuilder(" select ");
			sql.append(" DISTINCT NBR_AlarmTeste.SystemName, NBR_AlarmTeste.UnitName, cast(NBR_AlarmTeste.[Occurrence DateTime] as datetime) as OccurrenceDateTime, ");
			sql.append("  NBR_AlarmTeste.[Alarm State], ");
			sql.append(" NBR_AlarmTeste.MonitorAlarmName, NBR_AlarmTeste.SysNum, NBR_AlarmTeste.[Monitor Alarm Name] as Circuito, NBR_AlarmTeste.SystemNumber ");
			sql.append(" from NBR_AlarmTeste WHERE ");
			sql.append(" NBR_AlarmTeste.[Alarm State]='offNormal' and ");
			sql.append(" NBR_AlarmTeste.[Occurrence DateTime] >= DATEADD(HH, -");
			sql.append(h);
			sql.append(" , getdate()) ");
			sql.append(" ORDER BY OccurrenceDateTime DESC ");

			ps = connection.prepareStatement(sql.toString());
			rsLoop = ps.executeQuery();
		} catch (SQLException sqle) {
			if (connection != null) {
				connection.close();
				connection = null;
			}

			closeMainConnection();

			String title = "An error occurring in the main query of the Honeywell Opus";
			String description = sqle.toString();

			throw new RobotException(title + "- " + description);
		}

		while (rsLoop.next()) {
			// Test if the connection is opened.
			try {
				connection.createStatement().executeQuery("SELECT 1");
			} catch (SQLException sqle) {
				if (connection != null && !connection.isClosed()) {
					connection.close();
					connection = null;
				}

				break;
			}

			Long currentNum = 0L;
			String unitCode = rsLoop.getString("SystemNumber");
			String unitName = rsLoop.getString("SystemName");
			String alarmName = rsLoop.getString("MonitorAlarmName");
			Date dataDoAlarme = rsLoop.getTimestamp("OccurrenceDateTime");
			String circuito = rsLoop.getString("Circuito");
			String tipoDoRack = rsLoop.getString("UnitName");

			if (alarmName == null || "".equals(alarmName)) {
				alarmName = circuito;
			}
			
			//TODO Chamar metodo de atualizar data ultima captura
			
			Integer codUnidade = null;
			try {
				codUnidade = getCodUnidade(unitCode);
			} catch (RobotException e) {
				continue;
			}
			
			atualizarDataUltimoEnvioUnidade(codUnidade);
			
			if (checkIfAlarmHasAlreadyBeenInserted(alarmName, unitName,
					circuito, tipoDoRack)) {
				continue;
			}

			if (unitCode == null) {
				String title = "There was error when get 'SystemNumber' value";
				String description = String
						.format("'SystemNumber' field is null to Honeywell Opus' alert #%d",
								currentNum);
				logAndSendEmail(title, description);
				continue;
			}

			Integer alertaPadrao = null;
			try {
				alertaPadrao = getDefaultAlertMessage(alarmName);
			} catch (RobotException e) {
				continue;
			}

			Integer statusAlerta = getSemaforo(alertaPadrao);

			if (statusAlerta == null) {
				statusAlerta = 0;
			}

			try {
				insertAlertaControlador(alarmName, alertaPadrao, codUnidade,
						statusAlerta, dataDoAlarme, currentNum, circuito,
						tipoDoRack, unitName, null);
			} catch (RobotException e) {
				String title = "There was error when inserting the 'AlertaControlador' table";
				String description = e.getMessage();
				logAndSendEmail(title, description);
			}
		}

		if (connection != null) {
			connection.close();
			connection = null;
		}

		closeMainConnection();

		return FANTASIA;
	}
}
