package br.com.walmart.dashboard.robot.task;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import br.com.walmart.dashboard.robot.exception.RobotException;
import br.com.walmart.dashboard.robot.util.PropertyHandler;
import br.com.walmart.encrypter.Encrypter;

public class DanfossInvalidTask extends GenericTask {

	private final String FANTASIA = "danfoss";

	public DanfossInvalidTask() throws RobotException {
		setFantasia(FANTASIA);
		setFornecedor(FANTASIA);
	}

	@Override
	public String call() throws Exception {
		Connection connection = null;

		String driver = null;
		String url = null;
		String user = null;
		String pwd = null;

		if (connection == null || (connection != null && connection.isClosed())) {

			driver = PropertyHandler.getInstance().getValue(
					"DANFOSS_MYSQL_DRIVER");
			url = PropertyHandler.getInstance().getValue("DANFOSS_MYSQL_URL");
			user = PropertyHandler.getInstance().getValue("DANFOSS_MYSQL_USER");
			pwd = PropertyHandler.getInstance().getValue("DANFOSS_MYSQL_PWD");

			if (pwd != null && !pwd.isEmpty()) {
				pwd = new Encrypter().decrypt(pwd);
			}

			try {
				Class.forName(driver);
				connection = DriverManager.getConnection(url, user, pwd);
			} catch (SQLException sqle) {
				closeMainConnection();

				String title = String
						.format("There was error when connect to Danfoss' Invalid MySQL Server.");
				String description = sqle.toString();

				throw new RobotException(title + " - " + description);
			}
		}
		
		String h = PropertyHandler.getInstance().getValue("ALARM_DURATION_DANFOSS_INVALID");
		if (h == null || "".equals(h)) {
			h = "30";
		}
		
		getInvalidAlarmDanfoss(connection, h);
		
		if (connection != null) {
			connection.close();
			connection = null;
		}

		closeMainConnection();

		return FANTASIA;
	}

	private void getInvalidAlarmDanfoss(Connection connection, String h) throws SQLException, RobotException, Exception{
		
		String sql = null;
		PreparedStatement ps = null;
		ResultSet rsLoop = null;
		
		sql = " SELECT alarm_nbr, received_ts, alarm_data_txt "
				+ " FROM danfossramp.invalid_alarm "
				+ " WHERE received_ts >= date_add(now(), INTERVAL '-"
				+ h
				+ " " + h + "' MINUTE) " + " ORDER BY received_ts DESC ";
		
		try {
			ps = connection.prepareStatement(sql);
			rsLoop = ps.executeQuery();
			
			while (rsLoop.next()) {
				
				Long currentNum = rsLoop.getLong("alarm_nbr");
				Date dataDoAlarme = rsLoop.getTimestamp("received_ts");
				String alarmDataText = rsLoop.getString("alarm_data_txt");
				String [] alarms = alarmDataText.split("-{80}");
				
				for(String alarm: alarms){
					if((alarm.contains("Alta press�o") || alarm.contains("Falha sensor") || alarm.contains("Alta Temperatura") || 
					   alarm.contains("Baixa Temperatura") || alarm.contains("Baixa Press�o") || alarm.contains("N�vel l�q. baixo") ||
					   alarm.contains("Falha �leo comp")) && !alarm.contains("<")){
						
						String[] properties = alarm.replaceAll("\r+","").split("\n+");
						String unitName = properties[2].split(" ")[0].trim();
						String unitNameOriginal = properties[2].split(" ")[0].trim();
						String alarmName = properties[5].split("  +")[0];
						String circuito = properties[5].split("  +")[1];
						String tipoDoRack = properties[4].trim();
						insertAlarmInvalidDanfoss(alarmName, unitName, unitNameOriginal, circuito, tipoDoRack, currentNum, dataDoAlarme, "Danfoss inv�lido");
					}
				}
			}

		} catch (SQLException e) {
			if (connection != null) {
				connection.close();
				connection = null;
			}

			closeMainConnection();

			String title = "An error occurring in the main query of the Danfoss Invalid";
			String description = e.toString();

			throw new Exception(title + " - " + description);
		}
		
	}

	
	private void insertAlarmInvalidDanfoss(String alarmName, String unitName, String unitNameOriginal, String circuito, String tipoDoRack, Long currentNum, Date dataDoAlarme, String dsAlerta) throws RobotException, SQLException{
		//TODO Chamar metodo de atualizar data ultima captura
		
		Integer codUnidade = null;
		codUnidade = getCodUnidade(unitName);
		
		atualizarDataUltimoEnvioUnidade(codUnidade);
		
		if (checkIfAlarmHasAlreadyBeenInserted(alarmName, unitName,
				circuito, tipoDoRack)) {
			return;
		}

		if (unitName == null) {
			String title = "There was error when get 'Controller[Site_unit_name]' value";
			String description = String
					.format("'Controller[Site_unit_name]' Field is null to Danfoss' Invalid alert #%d",
							currentNum);
			logAndSendEmail(title, description);
			return;
		}

		if (!unitName.isEmpty()) {
			String[] split = unitName.split(" ");
			unitName = split[0];
		}

		if ("".equals(unitName)) {
			String title = "There was error when get 'Codigo legado'";
			String description = String.format(
					"Unit's code is blank to Danfoss' Invalid alert #%d for %s",
					currentNum, circuito);
			
			if(!errorEmailSent(currentNum)){
				logAndSendEmail(title, description);
				insertLogEmailSent(currentNum);
			}
			return;
		}

		Integer alertaPadrao = null;
		alertaPadrao = getDefaultAlertMessage(alarmName);


		Integer statusAlerta = getSemaforo(alertaPadrao);

		if (statusAlerta == null) {
			statusAlerta = 0;
		}

		try {
			insertAlertaControlador(alarmName, alertaPadrao, codUnidade,
					statusAlerta, dataDoAlarme, currentNum, circuito,
					tipoDoRack, unitNameOriginal, dsAlerta);
		} catch (RobotException e) {
			String title = "There was error when inserting the 'AlertaControlador' table";
			String description = e.getMessage();
			logAndSendEmail(title, description);
		}
	}
}