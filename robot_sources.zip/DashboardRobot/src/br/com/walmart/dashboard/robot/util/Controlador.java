package br.com.walmart.dashboard.robot.util;

public class Controlador {

	private Integer controladorId;
	private String nomeAlertaPadrao;
	private Integer IdAlertaPadrao;
	private Integer codigoUnidade;
	private String ipComunicacao;
	private String fornecedor;
	private Integer tipoCriticidade;
	private String circuito;

	public Integer getControladorId() {
		return controladorId;
	}

	public void setControladorId(Integer controladorId) {
		this.controladorId = controladorId;
	}

	public String getNomeAlertaPadrao() {
		return nomeAlertaPadrao;
	}

	public void setNomeAlertaPadrao(String nomeAlertaPadrao) {
		this.nomeAlertaPadrao = nomeAlertaPadrao;
	}

	public Integer getIdAlertaPadrao() {
		return IdAlertaPadrao;
	}

	public void setIdAlertaPadrao(Integer idAlertaPadrao) {
		IdAlertaPadrao = idAlertaPadrao;
	}

	public Integer getCodigoUnidade() {
		return codigoUnidade;
	}

	public void setCodigoUnidade(Integer codigoUnidade) {
		this.codigoUnidade = codigoUnidade;
	}

	public String getIpComunicacao() {
		return ipComunicacao;
	}

	public void setIpComunicacao(String ipComunicacao) {
		this.ipComunicacao = ipComunicacao;
	}

	public String getFornecedor() {
		return fornecedor;
	}

	public void setFornecedor(String fornecedor) {
		this.fornecedor = fornecedor;
	}

	public Integer getTipoCriticidade() {
		return tipoCriticidade;
	}

	public void setTipoCriticidade(Integer tipoCriticidade) {
		this.tipoCriticidade = tipoCriticidade;
	}

	public String getCircuito() {
		return circuito;
	}

	public void setCircuito(String circuito) {
		this.circuito = circuito;
	}

}
