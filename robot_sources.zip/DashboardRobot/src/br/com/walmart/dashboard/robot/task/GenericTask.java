package br.com.walmart.dashboard.robot.task;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.regex.Matcher;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import br.com.walmart.dashboard.robot.connection.RobotConnection;
import br.com.walmart.dashboard.robot.email.Contato;
import br.com.walmart.dashboard.robot.email.EmailService;
import br.com.walmart.dashboard.robot.email.TemplateEmail;
import br.com.walmart.dashboard.robot.exception.RobotException;
import br.com.walmart.dashboard.robot.util.PropertyHandler;
import br.com.walmart.encrypter.Encrypter;

public class GenericTask implements Callable<String> {

	protected Connection mainMSSQL;

	private String fantasia;
	private String fornecedor;
	private static final Logger logger = LogManager.getLogger(GenericTask.class); 
	private static final int CONTROLADOR_DESCONECTADO = 6420;
	private static final int ALARME_ENCERRADO = 5;

	public GenericTask() throws RobotException {
		createConnection();
	}

	public Connection getMainMSSQL() {
		return mainMSSQL;
	}

	public void setMainMSSQL(Connection connection) {
		this.mainMSSQL = connection;
	}

	public String getFantasia() {
		return fantasia;
	}

	public void setFantasia(String fantasia) {
		this.fantasia = fantasia;
	}

	public String getFornecedor() {
		return fornecedor;
	}

	public void setFornecedor(String fornecedor) {
		this.fornecedor = fornecedor;
	}

	@Override
	public String call() throws Exception {
		return null;
	}

	protected boolean validField(Object obj, String field, Long id)
			throws RobotException {
		if (obj == null) {
			String title = String.format("%s: Interrupted process",
					fantasia.toUpperCase());
			String description = String.format(
					"%s is null. Process of the alarm #%s interrupted.", field,
					id);
			logAndSendEmail(title, description);
			return false;
		}

		return true;
	}

	protected void logAndSendEmail(String title, String description)
			throws RobotException {
		throwsException(title, description);
	}

	protected void throwsException(String title, String description)
			throws RobotException {
		throwsException(title, description, null, null, null);
	}

	protected void throwsException(String title, String description,
			String codLoja, String alerta, Date dtOcorrencia)
			throws RobotException {

		logger.error("throwsException() - title: "+ title + 
				" description: "+description +" codLoja: "+codLoja + " alerta: "+alerta+" dtOcorrencia: "+dtOcorrencia);
		if (!isSendEmail()) {
			return;
		}

		if (codLoja != null && alerta != null && dtOcorrencia != null) {
			// insertAlertaErro(codLoja, alerta, dtOcorrencia);
		}

		ExecutorService executor = Executors.newFixedThreadPool(1);
		Callable<String> task = new EmailService(title, description, null,
				null, true);

		try {
			Future<String> future = executor.submit(task);
			future.get();
		} catch (InterruptedException | ExecutionException e) {
			throw new RobotException(e.getMessage());
		} finally {
			executor.shutdown();
		}
	}

	private boolean isSendEmail() throws RobotException {
		try {
			String sql = "SELECT EnviarEmail FROM ConfigRobo with (nolock) WHERE EnviarEmail = 'S'";
			ResultSet rs = mainMSSQL.createStatement().executeQuery(sql);
			return rs.next();
		} catch (SQLException sqle) {
			throw new RobotException(sqle.toString());
		}
	}

	protected boolean checkIfAlarmHasAlreadyBeenInserted(String nomeDoAlarme,
			String nomeDaLoja, String circuito, String tipoDoRack)
			throws RobotException {
		String h = getAlarmDuration();
		logger.info("checkIfAlarmHasAlreadyBeenInserted() - begin");
		try {			
			String sql = "SELECT COUNT(1) FROM AlertaControlador with (nolock) WHERE NmAlerta = ? AND "
					+ " (NomeUnidade = ? or NomeUnidade is null) AND (Circuito = ? or Circuito is null) "
					+ " AND (TipoRack = ? or TipoRack is null) AND Fornecedor = ? "
					+ " AND (StatusAlerta <> 5 OR (StatusAlerta = 5 AND "
					+ " (DtOcorrencia BETWEEN DATEADD(HOUR, -"
					+ h
					+ ", GETDATE()) AND GETDATE()))) ";
			PreparedStatement ps = mainMSSQL.prepareStatement(sql);
			ps.setString(1, nomeDoAlarme);
			ps.setString(2, nomeDaLoja);

			if (circuito != null && tipoDoRack != null
					&& !"".equals(tipoDoRack)) {
				circuito += (" / " + tipoDoRack);
			}

			ps.setString(3, circuito);
			ps.setString(4, tipoDoRack);
			ps.setString(5, fantasia);
			
			logger.info("checkIfAlarmHasAlreadyBeenInserted() - 1.nomeDoAlarme: " + nomeDoAlarme + " 2.nomeDaLoja: " + nomeDaLoja + " 3.circuito: "+circuito+" 4.tipoDoRack: "+circuito+" 5.fantasia: "+fantasia);
		
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				if (rs.getLong(1) > 0) {
					logger.info("checkIfAlarmHasAlreadyBeenInserted() - Alarm already inserted! RETURN true");
					return true;
				}
			}
		} catch (SQLException sqle) {
			throw new RobotException(sqle.toString());
		}
		logger.info("checkIfAlarmHasAlreadyBeenInserted() - Alarm not inserted yet! RETURN false");
		return false;
	}

	protected Integer getDefaultAlertMessage(String alarmText)
			throws RobotException {
		Integer alertaPadrao = null;
		logger.info("getDefaultAlertMessage() - begin");
		try {

			String sql = "SELECT c.IdAlertaPadrao, c.NmAlertaPadrao FROM alertafornecedor a with (nolock), associacaoalertasistema b with (nolock), alertapadrao c with (nolock) "
					+ " where a.NmAlertaFornecedor = ? and a.IdAlertaFornecedor = b.IdAlertaFornecedor "
					+ " and b.IdAlertaPadrao = c.IdAlertaPadrao and c.Excluido <> 'X' order by c.prioridade desc";
			PreparedStatement ps = mainMSSQL.prepareStatement(sql);
			ps.setString(1, alarmText);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				alertaPadrao = rs.getInt(1);
			}
			logger.info("getDefaultAlertMessage() - SELECT 1 - 1.alarmText: " + alarmText);
		} catch (SQLException sqle) {
			String title = String
					.format("There was an error when get default alert message to %s's controllers",
							fantasia);
			String description = String
					.format("%s: Don't get the default alert message to %s's controllers.",
							sqle.getMessage(), fantasia);
			logger.error("getDefaultAlertMessage() - SQLException 1: " + title + " "+ description);
			throwsException(title, description);
			throw new RobotException(description);
		}

		if (alertaPadrao == null) {
			PreparedStatement ps = null;
			ResultSet rs = null;

			try {
				Long idAlertaFornecedor = null;
				Integer idModeloFornecedor = null;

				String sql = "SELECT TOP 1 IdModeloFornecedor FROM ModeloFornecedor with (nolock) WHERE lower(Fornecedor) = ?";
				ps = mainMSSQL.prepareStatement(sql);
				ps.setString(1, fornecedor);
				rs = ps.executeQuery();
				logger.info("getDefaultAlertMessage() - SELECT 2 ModeloFornecedor - 1.fornecedor:" + fornecedor);

				if (rs.next()) {
					idModeloFornecedor = rs.getInt(1);
				} else {
					String title = String
							.format("There is not 'IdModeloFornecedor' to %s controller",
									fornecedor.toUpperCase());
					String description = title;
					logger.error("getDefaultAlertMessage() - SQLException 2: " + title + " "+ description);
					throwsException(title, description);
					throw new RobotException();
				}

				// Verifica se ha alarme fornecedor
				sql = "SELECT IdAlertaFornecedor FROM AlertaFornecedor with (nolock) WHERE IdModeloFornecedor = ? AND NmAlertaFornecedor = ?";
				ps = mainMSSQL.prepareStatement(sql);
				ps.setInt(1, idModeloFornecedor);
				ps.setString(2, alarmText);
				rs = ps.executeQuery();
				logger.info("getDefaultAlertMessage() - SELECT 3 AlertaFornecedor - 1.idModeloFornecedor:" + idModeloFornecedor);

				if (rs.next()) {
					idAlertaFornecedor = rs.getLong(1);
				}

				mainMSSQL.createStatement().execute("BEGIN TRANSACTION;");

				if (idAlertaFornecedor == null) {
					sql = "INSERT INTO AlertaFornecedor(IdModeloFornecedor, NmAlertaFornecedor) VALUES(?, ?)";
					ps = mainMSSQL.prepareStatement(sql);
					ps.setInt(1, idModeloFornecedor);
					ps.setString(2, alarmText);
					ps.execute();
					logger.info("getDefaultAlertMessage() - INSERT AlertaFornecedor - 1.idModeloFornecedor:" + idModeloFornecedor+ " 2.alarmText: "+alarmText);

					sql = "SELECT IdAlertaFornecedor FROM AlertaFornecedor with (nolock) WHERE IdModeloFornecedor = ? AND NmAlertaFornecedor = ?";
					ps = mainMSSQL.prepareStatement(sql);
					ps.setInt(1, idModeloFornecedor);
					ps.setString(2, alarmText);
					rs = ps.executeQuery();

					if (rs.next()) {
						idAlertaFornecedor = rs.getLong(1);
					} else {
						rollback();

						String title = "Error getting the ID AlertaFornecedor";
						String description = String
								.format("An error occurred getting the last AlertaFornecedor table to \"[%d] %s\"",
										idModeloFornecedor, alarmText);
						logger.error("getDefaultAlertMessage() - SQLException 3: " + title + " "+ description);
						throwsException(title, description);
						throw new RobotException();
					}
				}

				alertaPadrao = null;
				sql = "SELECT IdAlertaPadrao FROM AlertaPadrao with (nolock) WHERE NmAlertaPadrao = ? AND Excluido <> 'X' ";
				ps = mainMSSQL.prepareStatement(sql);
				ps.setString(1, alarmText);
				rs = ps.executeQuery();
				logger.info("getDefaultAlertMessage() - INSERT AlertaPadrao - 1.idModeloFornecedor:" + idModeloFornecedor+ " 2.alarmText: "+alarmText);
				if (rs.next()) {
					alertaPadrao = rs.getInt(1);
				}

				if (alertaPadrao == null) {
					sql = "INSERT INTO AlertaPadrao(NmAlertaPadrao, Prioridade, Excluido) VALUES(?, ?, 'N')";
					ps = mainMSSQL.prepareStatement(sql);
					ps.setString(1, alarmText);
					ps.setInt(2, 1);
					ps.execute();
					logger.info("getDefaultAlertMessage() - INSERT AlertaPadrao - 1.alarmText: " + alarmText+" 2.prioridade: 1 ");

					sql = "SELECT IdAlertaPadrao FROM AlertaPadrao with (nolock) WHERE NmAlertaPadrao = ? AND Excluido = 'N' order by prioridade desc ";
					ps = mainMSSQL.prepareStatement(sql);
					ps.setString(1, alarmText);
					rs = ps.executeQuery();

					if (rs.next()) {
						alertaPadrao = rs.getInt(1);
					}
				}

				if (alertaPadrao == null) {
					rollback();

					String title = "Error getting the ID AlertaPadrao";
					String description = String
							.format("An error occurred getting the last AlertaPadrao table to \"%s\"",
									alarmText);
					logger.error("getDefaultAlertMessage() - SQLException 4: " + title + " "+ description);
					throwsException(title, description);
					throw new RobotException();
				}

				sql = "INSERT INTO AssociacaoAlertaSistema(IdAlertaPadrao, IdAlertaFornecedor) VALUES(?, ?)";
				ps = mainMSSQL.prepareStatement(sql);
				ps.setLong(1, alertaPadrao);
				ps.setLong(2, idAlertaFornecedor);
				ps.execute();
				logger.info("getDefaultAlertMessage() - INSERT AssociacaoAlertaSistema - 1.alertaPadrao: " + alertaPadrao + " 2.idAlertaFornecedor: "+ idAlertaFornecedor);

				mainMSSQL.createStatement().execute("COMMIT TRANSACTION;");
			} catch (SQLException sqle) {
				rollback();

				String title = String
						.format("There was an error when it tried process a(n) %s's alarm",
								fantasia.toUpperCase());
				String description = sqle.getMessage();
				logger.error("getDefaultAlertMessage() - SQLException 5: " + title + " "+ description);
				throwsException(title, description);
				throw new RobotException(description);
			}
		}

		logger.info("getDefaultAlertMessage() - RETURN alertaPadrao: " + alertaPadrao);
		return alertaPadrao;
	}

	protected void rollback() {
		try {
			mainMSSQL.createStatement().execute("ROLLBACK TRANSACTION;");
		} catch (SQLException e) {
			// :~
		}
	}

	protected Integer getCodUnidade(String siteName) throws RobotException {
		Integer codUnidade = null;

		// siteName = siteName.replaceAll("[^a-zA-Z0-9 ]", "").trim();
		siteName = siteName.replaceAll("[^0-9]", "").trim();

		String rede = PropertyHandler.getInstance().getValue("REGION_NETWORK");
		String sql = null;
		logger.info("getCodUnidade() - begin");

		if ("SUDESTE".equals(rede) || "BIG".equals(rede)) {
			sql = "select CodUnidade, Status from CadastroUnidade with (nolock) where Rede = ? "
					+ " and CodBv = ? ";
		} else {
			sql = "select CodUnidade, Status from CadastroUnidade with (nolock) where Rede = ? "
					+ " and cast(SUBSTRING(CodigoLegado, 2, 20) as int) = ? ";
		}

		PreparedStatement ps;

		try {
			ps = mainMSSQL.prepareStatement(sql);
			ps.setString(1, rede);
			ps.setString(2, siteName);

			ResultSet rs = ps.executeQuery();
			logger.info("getCodUnidade() - SELECT 1 - 1.rede: "+rede+" 2.siteName: "+siteName);

			if (rs.next()) {
				String status = rs.getString("Status");

				if ("I".equals(status)) {
					logger.error("getCodUnidade() - RobotException 1 - Inactive unit won't be processed.");
					throw new RobotException(
							"Inactive unit won't be processed.");
				}

				codUnidade = rs.getInt("CodUnidade");

			} else { // Unknow
				ps = mainMSSQL.prepareStatement(sql);
				ps.setString(1, rede);
				ps.setString(2, "99999");
				rs = ps.executeQuery();
				if (rs.next()) {
					codUnidade = rs.getInt("CodUnidade");
				}
			}
		} catch (SQLException e) {
			String msg = e.getMessage();
			logAndSendEmail("There was error when get 'Unidade'", msg);
			logger.error("getCodUnidade() - SQLException 1 - msg: "+msg);
			throw new RobotException(msg);
		}

		if (codUnidade == null) {
			String msg = String.format(
					"There isn't 'Unidade' of the 'Codigo legado' #%s to %s",
					siteName, fantasia);
			logAndSendEmail("There was error when get 'Unidade'", msg);
			logger.error("getCodUnidade() - SQLException 2 - msg: "+msg);
			throw new RobotException(msg);
		}

		logger.info("getCodUnidade() - RETURN codUnidade: "+codUnidade);
		return codUnidade;
	}

	protected Integer getSemaforo(Integer idAlertaPadrao) throws RobotException {
		logger.info("getSemaforo() - begin");
		try {
			String sql = "SELECT TpCriticidade FROM AlertaPadrao AP  with (nolock) "
					+ " INNER JOIN CRITICIDADEALERTA CA  with (nolock) ON AP.IdAlertaPadrao = CA.IdAlertaPadrao "
					+ "  WHERE AP.IdAlertaPadrao = ?";
			PreparedStatement ps = mainMSSQL.prepareStatement(sql);
			ps.setInt(1, idAlertaPadrao);
			ResultSet rs = ps.executeQuery();
			logger.info("getSemaforo() - SELECT - 1.idAlertaPadrao: "+idAlertaPadrao);

			if (rs.next()) {
				logger.info("getSemaforo() - RETURN rs.getInt(1): "+rs.getInt(1));
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			logger.error("getSemaforo() - SQLException: "+e.getMessage());
			throw new RobotException(e.getMessage());
		}

		logger.info("getSemaforo() - RETURN null");
		return null;
	}

	protected void insertAlertaControlador(String alarmText,
			Integer alertaPadrao, Integer codUnidade, Integer statusAlerta,
			Date dtOcorrencia, Long idLegado, String circuito,
			String tipoDoRack, String unitName, String fantasia, String dsAlerta)
			throws RobotException {
		this.fantasia = fantasia;

		insertAlertaControlador(alarmText, alertaPadrao, codUnidade,
				statusAlerta, dtOcorrencia, 0L, circuito, tipoDoRack, unitName, dsAlerta);
	}

	protected void insertAlertaControlador(String alarmText,
			Integer alertaPadrao, Integer codUnidade, Integer statusAlerta,
			Date dtOcorrencia, Long idLegado, String circuito,
			String tipoDoRack, String unitName, String dsAlerta) throws RobotException {

		Long idAlerta = null;
		logger.info("insertAlertaControlador() - begin");

		try {
			mainMSSQL.createStatement().execute("BEGIN TRANSACTION;");
			

//			mainMSSQL.createStatement().execute("ROLLBACK TRANSACTION;");

			String sql = "INSERT INTO AlertaControlador(NmAlerta, IdAlertaPadrao, CodUnidade, StatusAlerta, "
					+ "DtCaptura, DtOcorrencia, Fornecedor, IdLegado, DtAtualizacao, Circuito, TipoRack, NomeUnidade, "
					+ " AlarmeFornecedor, DsAlerta ) "
					+ " VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
			PreparedStatement ps = mainMSSQL.prepareStatement(sql);
			ps.setString(1, alarmText);
			ps.setInt(2, alertaPadrao);
			ps.setInt(3, codUnidade);
			ps.setInt(4, statusAlerta);
			ps.setTimestamp(5, new Timestamp(new Date().getTime()));
			ps.setTimestamp(6, new Timestamp(dtOcorrencia.getTime()));
			ps.setString(7, fantasia);
			ps.setLong(8, idLegado);
			ps.setTimestamp(9, new Timestamp(new Date().getTime()));

			if (circuito != null && tipoDoRack != null
					&& !"".equals(tipoDoRack)) {
				circuito += (" / " + tipoDoRack);
			}

			ps.setString(10, circuito);
			ps.setString(11, tipoDoRack);
			ps.setString(12, unitName);
			ps.setString(13, alarmText);
			ps.setString(14, dsAlerta);
			ps.execute();
			logger.info("insertAlertaControlador() - INSERT - 1.NmAlerta: "+alarmText 
					+ " 2.IdAlertaPadrao: "+alertaPadrao
					+ " 3.CodUnidade: "+codUnidade
					+ " 4.StatusAlerta: "+statusAlerta
					+ " 5.DtCaptura: "+new Timestamp(new Date().getTime())
					+ " 6.DtOcorrencia: "+new Timestamp(dtOcorrencia.getTime())
					+ " 7.Fornecedor: "+fantasia
					+ " 8.IdLegado: "+idLegado
					+ " 9.DtAtualizacao: "+new Timestamp(new Date().getTime())
					+ " 10.Circuito: "+circuito
					+ " 11.TipoRack: "+tipoDoRack
					+ " 12.NomeUnidade: "+unitName
					+ " 13.AlarmeFornecedor: "+alarmText);

			ResultSet rs = mainMSSQL.createStatement().executeQuery(
					"SELECT @@IDENTITY");

			if (rs.next()) {
				idAlerta = rs.getLong(1);
			} else {
				logger.error("insertAlertaControlador() - SQLException 1 - Unable retrieve the @@IDENTITY of the alarm #%d", idLegado);
				throw new SQLException(String.format(
						"Unable retrieve the @@IDENTITY of the alarm #%d",
						idLegado));
			}

			sql = "UPDATE ControleDashboardLegado SET CtrlLast = ? WHERE CtrlRede = ? AND CtrlFornecedor = ?";
			ps = mainMSSQL.prepareStatement(sql);
			ps.setLong(1, idLegado);
			ps.setString(2,
					PropertyHandler.getInstance().getValue("REGION_NETWORK"));
			ps.setString(3, fantasia);
			ps.execute();
			logger.info("insertAlertaControlador() - UPDATE ControleDashboardLegado - 1.CtrlLast/idLegado: "+idLegado+
					" 2.CtrlRede:"+PropertyHandler.getInstance().getValue("REGION_NETWORK")+" 3.CtrlFornecedor/fantasia: "+fantasia);
			
			if(!(alertaPadrao.equals(CONTROLADOR_DESCONECTADO) || statusAlerta.equals(ALARME_ENCERRADO))){
				atualizarDataUltimaCapturaUnidade(codUnidade);
			}

			mainMSSQL.createStatement().execute("COMMIT TRANSACTION;");

			checkCriticidadeAndSendEmail(idAlerta,
					"SP_CRITICIDADE_ALARME_INICIAL");
		} catch (SQLException e) {
			
			rollBackTransaction(idLegado, e, "insertAlertaControlador()");
		}
	}
	
	
	
	public void atualizarDataUltimoEnvioUnidade(Integer codUnidade) throws SQLException {
		
		String sql = "UPDATE CapturaUnidade SET DataUltimoEnvio = ? WHERE CodUnidade = ? and (DataUltimoEnvio is null or DataUltimoEnvio < ?)";
		PreparedStatement pStatement =  mainMSSQL.prepareStatement(sql);
		Timestamp dataEnvio = new Timestamp(new Date().getTime());
		pStatement.setTimestamp(1, dataEnvio);
		pStatement.setInt(2, codUnidade);
		pStatement.setTimestamp(3, dataEnvio);
		pStatement.executeUpdate();
		logger.info("atualizarDataUltimoEnvioUnidade() - UPDATE - 1.Unidade: "+codUnidade+" 2.Data Captura: "+ dataEnvio);
		
	}
	
	private void atualizarDataUltimaCapturaUnidade(Integer codUnidade) throws SQLException {
		
		String sql = "UPDATE CapturaUnidade SET DataUltimaCaptura = ? WHERE CodUnidade = ? ";
		Timestamp dataCaptura = new Timestamp(new Date().getTime());
		PreparedStatement pStatement =  mainMSSQL.prepareStatement(sql);
		pStatement.setTimestamp(1, dataCaptura);
		pStatement.setInt(2, codUnidade);
		
		if(pStatement.executeUpdate() == 0){
			sql = "INSERT INTO CapturaUnidade (CodUnidade, DataUltimaCaptura, DataUltimoEnvio) VALUES (?,?,?)";
			pStatement =  mainMSSQL.prepareStatement(sql);
			pStatement.setInt(1, codUnidade);
			pStatement.setTimestamp(2, dataCaptura);
			pStatement.setTimestamp(3, dataCaptura);
			pStatement.execute();
			logger.info("atualizarDataUltimaCapturaUnidade() - INSERT - 1.Unidade: "+codUnidade+" 2.Data Captura: "+ dataCaptura);
		
		} else {
			logger.info("atualizarDataUltimaCapturaUnidade() - UPDATE - 1.Unidade: "+codUnidade+" 2.Data Captura: "+ dataCaptura);
		}
		
	}

	protected boolean errorEmailSent(Long idAlarm) throws RobotException{
		
		logger.info("errorEmailSent() : " + idAlarm);
		
		try {
			
			String select = "SELECT CodigoAlarme FROM ControleEnvioEmail WHERE CodigoAlarme = ? AND DATEDIFF(hour, GETDATE(), DataEnvio) < ?";
			PreparedStatement ps = mainMSSQL.prepareStatement(select);
			ps.setLong(1, idAlarm);
			ps.setString(2, getAlarmDuration());
			ResultSet rs = ps.executeQuery();
			
			return rs.next();
		
		} catch (SQLException e) {
			throw new RobotException(e.getMessage());
		}
		
	}
	
	protected void insertLogEmailSent (Long idAlarm) throws RobotException{
		
		if(!updateLogEmailSent(idAlarm)){
			
			try {
			
				logger.info("insertLogEmailSent() alarm_nbr: " + idAlarm);

				mainMSSQL.createStatement().execute("BEGIN TRANSACTION;");
				String insert = "INSERT INTO ControleEnvioEmail (CodigoAlarme, DataEnvio) values (?, GETDATE())";
	
				PreparedStatement ps = mainMSSQL.prepareStatement(insert);
				ps.setLong(1, idAlarm);
				ps.execute();
				mainMSSQL.createStatement().execute("COMMIT TRANSACTION;");
				
			} catch (SQLException e) {
				
				rollBackTransaction(idAlarm, e, "insertLogEmailSent()");
			}
			
		}
		
	}
	
	
	private boolean updateLogEmailSent(Long idAlarm) throws RobotException{
		
		
		boolean updated = false;
		
		try {
			
			mainMSSQL.createStatement().execute("BEGIN TRANSACTION;");
			String update = "UPDATE ControleEnvioEmail SET DataEnvio = GETDATE() where CodigoAlarme = ?";
			
			PreparedStatement ps = mainMSSQL.prepareStatement(update);
			ps.setLong(1, idAlarm);
			
			updated = ps.executeUpdate() >  0; 
			mainMSSQL.createStatement().execute("COMMIT TRANSACTION;");
		
			if(updated)
				logger.info("updateLogEmailSent() alarm_nbr: " + idAlarm);
				
		
		} catch (SQLException e) {
			
			rollBackTransaction(idAlarm, e, "updateLogEmailSent()");
		}
		
		return updated;

	}


	protected void checkCriticidadeAndSendEmail(Long idAlerta, String procedure)
			throws SQLException, RobotException {
		logger.info("checkCriticidadeAndSendEmail() - begin");
		String sql = "{call " + procedure + " (?)}";
		PreparedStatement ps = mainMSSQL.prepareStatement(sql);
		CallableStatement csmt = mainMSSQL.prepareCall(sql);
		csmt.setEscapeProcessing(true);
		csmt.setQueryTimeout(90);
		csmt.setLong(1, idAlerta);
		
		csmt.execute();
		ResultSet rs = csmt.getResultSet();
		logger.info("checkCriticidadeAndSendEmail() - EXEC procedure: "+procedure + " 1. idAlerta: "+idAlerta);

		TemplateEmail templateEmail = null;
		if (rs.next()) {
			if (templateEmail == null) {
				templateEmail = new TemplateEmail();
			}

			String corpo = rs.getString("CorpoEmail");

			if (corpo == null) {
				return;
			}

			templateEmail.setCodigoUnidade(rs.getString("CodUnidade"));
			templateEmail.setCodigoLegado(rs.getString("CodigoLegado"));
			templateEmail.setNomeLoja(rs.getString("NmLoja"));
			templateEmail.setBandeira(rs.getString("Bandeira"));
			templateEmail.setDataOcorrencia(rs.getTimestamp("DtOcorrencia"));
			templateEmail.setTipoAlerta(rs.getString("NmAlertaPadrao"));
			templateEmail.setChamadoInterno(rs.getString("NuChamadoInterno"));
			templateEmail.setChamadoExterno(rs.getString("NuChamadoExterno"));
			templateEmail.setRegiao(rs.getString("Regiao"));
			templateEmail.setUf(rs.getString("Estado"));

			String assunto = rs.getString("AssuntoEmail");
			assunto = assunto.replaceAll("##CODIGO_DA_UNIDADE",
					templateEmail.getCodigoUnidade());
			templateEmail.setAssunto(assunto);

			String sDataOcorrencia = "";

			if (templateEmail.getDataOcorrencia() != null) {
				DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
				sDataOcorrencia = df.format(templateEmail.getDataOcorrencia());
			}

			if (corpo != null) {
				corpo = corpo.replaceAll("##CODIGO_DA_UNIDADE",
						templateEmail.getCodigoUnidade());
				corpo = corpo.replaceAll("##CODIGO_LEGADO",
						templateEmail.getCodigoLegado());
				corpo = corpo.replaceAll("##NOME_LOJA",
						templateEmail.getNomeLoja());
				corpo = corpo.replaceAll("##BANDEIRA",
						templateEmail.getBandeira());
				corpo = corpo.replaceAll("##DATA_HORA_OCORRENCIA",
						sDataOcorrencia);
				corpo = corpo.replaceAll("##REGIAO", templateEmail.getRegiao());
				corpo = corpo.replaceAll("##UF", templateEmail.getUf());
				corpo = corpo
						.replaceAll("##TIPO_ALERTA",
								Matcher.quoteReplacement(templateEmail
										.getTipoAlerta()));

				if (templateEmail.getChamadoInterno() == null) {
					templateEmail.setChamadoInterno("");
				}

				corpo = corpo.replaceAll("##CHAMADO_INTERNO",
						templateEmail.getChamadoInterno());

				if (templateEmail.getChamadoExterno() == null) {
					templateEmail.setChamadoExterno("");
				}

				corpo = corpo.replaceAll("##CHAMADO_EXTERNO",
						templateEmail.getChamadoExterno());

				if (corpo.indexOf("##HISTORICO_ATENDIMENTO") > -1) {
					sql = "SELECT DtInclusao, DsAtuacao, NmUsuario, FlStatus FROM AlertaControladorDetalhe with (nolock) WHERE IdAlerta = ?";
					ps = mainMSSQL.prepareStatement(sql);
					ps.setLong(1, idAlerta);
					ResultSet rsHistAtend = ps.executeQuery();

					StringBuilder historicoAtendimento = new StringBuilder(
							"<ul>");

					String nmUsuario = null;
					String flStatus = null;
					Date dataHoraInicioAtendimento = null;

					int countHistory = 0;

					while (rsHistAtend.next()) {
						if (nmUsuario == null) {
							nmUsuario = rsHistAtend.getString("NmUsuario");
						}

						if (flStatus == null) {
							flStatus = rsHistAtend.getString("FlStatus");
						} else if ("2".equals("FlStatus")) {
							flStatus = rsHistAtend.getString("FlStatus");
						}

						Timestamp dataInclusao = rsHistAtend
								.getTimestamp("DtInclusao");

						if (dataHoraInicioAtendimento == null
								|| dataInclusao
										.before(dataHoraInicioAtendimento)) {
							dataHoraInicioAtendimento = dataInclusao;
						}

						historicoAtendimento.append("<li>");
						historicoAtendimento.append(rsHistAtend.getString(1));
						historicoAtendimento.append(" - ");
						historicoAtendimento.append(rsHistAtend.getString(2));
						historicoAtendimento.append("</li>");

						countHistory++;
					}

					historicoAtendimento.append("</ul>");

					if (nmUsuario == null) {
						nmUsuario = "";
					}

					corpo = corpo
							.replaceAll("##USUARIO_RESPONSAVEL", nmUsuario);

					if ("2".equals("FlStatus")) {
						flStatus = "Encerrado";
					} else if ("1".equals("FlStatus")) {
						flStatus = "Em Atendimento";
					} else {
						flStatus = "";
					}

					corpo = corpo.replaceAll("##STATUS", flStatus);

					if (dataHoraInicioAtendimento != null) {
						DateFormat df = new SimpleDateFormat(
								"dd/MM/yyyy HH:mm:ss");
						corpo = corpo.replaceAll(
								"##DATA_HORA_INICIO_ATENDIMENTO",
								df.format(dataHoraInicioAtendimento));
					} else {
						corpo = corpo.replaceAll(
								"##DATA_HORA_INICIO_ATENDIMENTO", "");
					}

					if (countHistory > 0) {
						corpo = corpo.replaceAll("##HISTORICO_ATENDIMENTO",
								historicoAtendimento.toString());
					} else {
						corpo = corpo.replaceAll("##HISTORICO_ATENDIMENTO",
								"N&atilde;o h&aacute; hist&oacute;rico.");
					}
				}
			}

			templateEmail.setCorpo(corpo);

			// Add the first fetch
			addContato(templateEmail, rs.getString("TpEnvio"),
					rs.getString("NmContato"), rs.getString("EmailContato"));
		}

		// Are there more contacts?
		while (rs.next()) { // Now it add only the contacts
			addContato(templateEmail, rs.getString("TpEnvio"),
					rs.getString("NmContato"), rs.getString("EmailContato"));
		}

		if (templateEmail != null && templateEmail.getCorpo() != null) {
			sendEmailByTemplate(templateEmail);
		}
	}

	private void addContato(TemplateEmail templateEmail, String tipoEnvio,
			String nome, String email) {
		List<Contato> list = templateEmail.getContatos().get(tipoEnvio);

		if (list == null) {
			list = new ArrayList<Contato>();
		}

		list.add(new Contato(nome, email));
		templateEmail.getContatos().put(tipoEnvio, list);
	}

	private void sendEmailByTemplate(TemplateEmail templateEmail)
			throws RobotException {
		if (!isSendEmail()) {
			return;
		}

		String subject = templateEmail.getAssunto();
		String content = templateEmail.getCorpo();

		List<Contato> to = templateEmail.getContatos().get("P");
		List<Contato> cc = templateEmail.getContatos().get("C");

		ExecutorService executor = Executors.newFixedThreadPool(1);
		Callable<String> task = new EmailService(subject, content, to, cc,
				false);

		try {
			Future<String> future = executor.submit(task);
			future.get();
		} catch (InterruptedException | ExecutionException e) {
			throw new RobotException(e.getMessage());
		} finally {
			executor.shutdown();
		}
	}

	protected void createConnection() throws RobotException {
		try {
			String password = new Encrypter().decrypt(PropertyHandler
					.getInstance().getValue("MAIN_MSSQL_PWD"));

			mainMSSQL = new RobotConnection().getConnection(PropertyHandler
					.getInstance().getValue("MAIN_MSSQL_DRIVER"),
					PropertyHandler.getInstance().getValue("MAIN_MSSQL_URL"),
					PropertyHandler.getInstance().getValue("MAIN_MSSQL_USER"),
					password);
		} catch (ClassNotFoundException cnfe) {
			throw new RobotException(cnfe.toString());
		} catch (SQLException sqle) {
			throw new RobotException(sqle.toString());
		} catch (IOException ioe) {
			throw new RobotException(ioe.toString());
		}
	}

	protected void closeMainConnection() throws RobotException {
		try {
			if (mainMSSQL != null) {
				mainMSSQL.close();
				mainMSSQL = null;
			}
		} catch (SQLException sqle) {
			throw new RobotException(sqle.toString());
		}

	}
	
	private String getAlarmDuration() {
		String h = PropertyHandler.getInstance().getValue("ALARM_DURATION");
		if (h == null || "".equals(h)) {
			h = "1";
		}
		return h;
	}
	
	private void rollBackTransaction(Long idAlarm, SQLException e, String operation) throws RobotException {
		
		try {
			mainMSSQL.createStatement().execute("ROLLBACK TRANSACTION;");
		} catch (SQLException sqle) {
			logger.error(operation + " - SQLException 2 - sqle: "+ sqle.getMessage());
		}
		
		String msg = String.format("ROLLBACK the %s's Alert # %d - %s",
				fantasia, idAlarm, e.getMessage());
		
		logger.error(operation + " - SQLException 3 - msg: "+ msg);
		throw new RobotException(msg);
	}
}
