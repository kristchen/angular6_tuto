package br.com.walmart.dashboard.robot.task;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.walmart.dashboard.robot.exception.RobotException;

public class SemaforoTask extends GenericTask {

	public SemaforoTask() throws RobotException {
	}

	public String call() throws Exception {
		ResultSet rs = null;

		try {
			String sql = "SELECT AC.IdAlerta AS IdAlerta FROM AlertaControlador AC with (nolock) "
					+ " INNER JOIN CriticidadeAlerta CA WITH (NOLOCK) ON CA.IdAlertaPadrao = AC.IdAlertaPadrao "
					+ "	WHERE AC.StatusAlerta NOT IN (4, 5) ORDER BY AC.NmAlerta ";
			PreparedStatement ps = mainMSSQL.prepareStatement(sql);
			rs = ps.executeQuery();
		} catch (SQLException sqle) {
			closeMainConnection();

			String title = "An error occurring in the main query of the Semaforo #1";
			String description = sqle.toString();

			throw new Exception(title + " - " + description);
		}

		while (rs.next()) {
			Long idAlerta = rs.getLong(1);

			try {
				checkCriticidadeAndSendEmail(idAlerta, "SP_CRITICIDADE_ALARME");
			} catch (SQLException sqle) {
				closeMainConnection();

				String title = "An error occurring in the main query of the Semaforo #2 (ID: " + idAlerta + ")";
				String description = sqle.toString();
				throw new RobotException(title + " - " + description);
			}
		}

		closeMainConnection();

		return "OK";
	}
}
