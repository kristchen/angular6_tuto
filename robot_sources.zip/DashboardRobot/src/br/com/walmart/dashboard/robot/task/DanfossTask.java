package br.com.walmart.dashboard.robot.task;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import br.com.walmart.dashboard.robot.exception.RobotException;
import br.com.walmart.dashboard.robot.util.PropertyHandler;
import br.com.walmart.encrypter.Encrypter;

public class DanfossTask extends GenericTask {

	private final String FANTASIA = "danfoss";

	public DanfossTask() throws RobotException {
		setFantasia(FANTASIA);
		setFornecedor(FANTASIA);
	}

	@Override
	public String call() throws Exception {
		Connection connection = null;

		String driver = null;
		String url = null;
		String user = null;
		String pwd = null;

		if (connection == null || (connection != null && connection.isClosed())) {

			driver = PropertyHandler.getInstance().getValue(
					"DANFOSS_MYSQL_DRIVER");
			url = PropertyHandler.getInstance().getValue("DANFOSS_MYSQL_URL");
			user = PropertyHandler.getInstance().getValue("DANFOSS_MYSQL_USER");
			pwd = PropertyHandler.getInstance().getValue("DANFOSS_MYSQL_PWD");

			if (pwd != null && !pwd.isEmpty()) {
				pwd = new Encrypter().decrypt(pwd);
			}

			try {
				Class.forName(driver);
				connection = DriverManager.getConnection(url, user, pwd);
			} catch (SQLException sqle) {
				closeMainConnection();

				String title = String
						.format("There was error when connect to Danfoss' MySQL Server.");
				String description = sqle.toString();

				throw new RobotException(title + " - " + description);
			}
		}

		String sql = null;
		PreparedStatement ps = null;
		ResultSet rsLoop = null;

		try {
			String h = PropertyHandler.getInstance().getValue("ALARM_DURATION");
			if (h == null || "".equals(h)) {
				h = "1";
			}

			sql = " SELECT valid_alarm.alarm_nbr as alarm_nbr, controller.site_unit_name as site_unit_name, "
					+ " valid_alarm.name_txt as name_txt, valid_alarm.received_ts as received_ts, "
					+ " valid_alarm.addr_type as addr_type, valid_alarm.class_txt as class_txt "
					+ " FROM danfossramp.valid_alarm, danfossramp.controller "
					+ " WHERE valid_alarm.controller_id = controller.controller_id "
					+ " AND received_ts >= date_add(now(), INTERVAL '-"
					+ h
					+ " " + h + "' HOUR) " + " ORDER BY received_ts DESC ";

			ps = connection.prepareStatement(sql);
			rsLoop = ps.executeQuery();
		} catch (SQLException sqle) {
			if (connection != null) {
				connection.close();
				connection = null;
			}

			closeMainConnection();

			String title = "An error occurring in the main query of the Danfoss";
			String description = sqle.toString();

			throw new Exception(title + " - " + description);
		}

		while (rsLoop.next()) {
			// Test if the connection is opened.
			try {
				connection.createStatement().executeQuery("SELECT 1");
			} catch (SQLException sqle) {
				if (connection != null && !connection.isClosed()) {
					connection.close();
					connection = null;
				}

				break;
			}

			Long currentNum = rsLoop.getLong("alarm_nbr");
			String unitName = rsLoop.getString("site_unit_name");
			String unitNameOriginal = rsLoop.getString("site_unit_name");
			String alarmName = rsLoop.getString("name_txt");
			Date dataDoAlarme = rsLoop.getTimestamp("received_ts");
			String circuito = rsLoop.getString("addr_type");
			String tipoDoRack = rsLoop.getString("class_txt");
			
			//TODO Chamar metodo de atualizar data ultima captura
			
			Integer codUnidade = null;
			try {
				codUnidade = getCodUnidade(unitName);
			} catch (RobotException e) {
				continue;
			}
			
			atualizarDataUltimoEnvioUnidade(codUnidade);
			
			if (checkIfAlarmHasAlreadyBeenInserted(alarmName, unitName,
					circuito, tipoDoRack)) {
				continue;
			}

			if (unitName == null) {
				String title = "There was error when get 'Controller[Site_unit_name]' value";
				String description = String
						.format("'Controller[Site_unit_name]' Field is null to Danfoss' alert #%d",
								currentNum);
				logAndSendEmail(title, description);
				continue;
			}

			if (!unitName.isEmpty()) {
				String[] split = unitName.split(" ");
				unitName = split[0];
			}

			if ("".equals(unitName)) {
				String title = "There was error when get 'Codigo legado'";
				String description = String.format(
						"Unit's code is blank to Danfoss' alert #%d for %s",
						currentNum, circuito);
				
				if(!errorEmailSent(currentNum)){
					logAndSendEmail(title, description);
					insertLogEmailSent(currentNum);
				}
				
				continue;
			}

			Integer alertaPadrao = null;
			try {
				alertaPadrao = getDefaultAlertMessage(alarmName);
			} catch (RobotException e) {
				continue;
			}


			Integer statusAlerta = getSemaforo(alertaPadrao);

			if (statusAlerta == null) {
				statusAlerta = 0;
			}

			try {
				insertAlertaControlador(alarmName, alertaPadrao, codUnidade,
						statusAlerta, dataDoAlarme, currentNum, circuito,
						tipoDoRack, unitNameOriginal, "");
			} catch (RobotException e) {
				String title = "There was error when inserting the 'AlertaControlador' table";
				String description = e.getMessage();
				logAndSendEmail(title, description);
			}

		}

		if (connection != null) {
			connection.close();
			connection = null;
		}

		closeMainConnection();

		return FANTASIA;
	}
}
