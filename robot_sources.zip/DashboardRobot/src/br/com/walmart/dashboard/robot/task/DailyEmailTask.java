package br.com.walmart.dashboard.robot.task;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

import br.com.walmart.dashboard.robot.exception.RobotException;

public class DailyEmailTask extends GenericTask {

	public DailyEmailTask() throws RobotException {
	}

	public String call() throws Exception {
		try {
			Calendar calendar = Calendar.getInstance();
			if ((calendar.get(Calendar.HOUR_OF_DAY) == 4 && calendar
					.get(Calendar.MINUTE) == 0)) {
				String sql = "SELECT AC.IdAlerta AS IdAlerta FROM AlertaControlador AC with (nolock) "
						+ " INNER JOIN CriticidadeAlerta CA WITH (NOLOCK) ON CA.IdAlertaPadrao = AC.IdAlertaPadrao "
						+ "	WHERE AC.StatusAlerta NOT IN (5) AND CA.FlEnviarEmailAzul = 'S' AND FreqEnvioEmailAzul = 2 "
						+ " ORDER BY AC.NmAlerta ";
				PreparedStatement ps = mainMSSQL.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();

				while (rs.next()) {
					Long idAlerta = rs.getLong(1);
					checkCriticidadeAndSendEmail(idAlerta, "SP_EMAIL_DIARIO");
				}
			}

			closeMainConnection();
		} catch (SQLException sqle) {
			closeMainConnection();

			String title = "An error occurring in the main query of the Daily Email";
			String description = sqle.toString();
			throw new RobotException(title + " - " + description);
		}

		return "OK";
	}
}
