package br.com.walmart.dashboard.robot.callable;

import static br.com.walmart.dashboard.robot.util.Log.ERROR;
import static br.com.walmart.dashboard.robot.util.Log.INFO;
import static br.com.walmart.dashboard.robot.util.Log.log;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import br.com.walmart.dashboard.robot.exception.RobotException;
import br.com.walmart.dashboard.robot.task.EmersonTask;

public class EmersonCallable implements Runnable {
	
	private String config;
	
	private static final Logger logger = LogManager
			.getLogger(EmersonCallable.class);
	
	
	
	public EmersonCallable(String config) {
		super();
		this.config = config;
	}

	@Override
	public void run() {
		while (true) {
			log(logger, INFO, "Started...");
			
			try {
				execute();
			} catch (InterruptedException e) {
				log(logger, ERROR, e.getMessage());
			} catch (ExecutionException e) {
				log(logger, ERROR, e.getMessage());
			} catch (RobotException e) {
				log(logger, ERROR, e.getMessage());
			} catch (RuntimeException e) {
				log(logger, ERROR, e.getMessage());
			}

			log(logger, INFO, "Ended.");

			try {
				Thread.sleep(60000);
			} catch (InterruptedException e) {
				log(logger, ERROR, e.getMessage());
			}
			
			System.gc();
		}
	}

	private void execute() throws InterruptedException, ExecutionException,
			RobotException {
		ExecutorService executor = Executors.newFixedThreadPool(1);
		Callable<String> task = new EmersonTask(config);
		Future<String> future = executor.submit(task);
		future.get();
		executor.shutdown();
	}

}
