package br.com.walmart.dashboard.robot.email;

public class Contato {

	private String personal;
	private String email;

	public Contato() {
		// :~
	}

	public Contato(String personal, String email) {
		this.personal = personal;
		this.email = email;
	}

	public String getPersonal() {
		return personal;
	}

	public void setPersonal(String personal) {
		this.personal = personal;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
