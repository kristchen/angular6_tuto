package br.com.walmart.dashboard.robot.email;

import static br.com.walmart.dashboard.robot.util.Log.ERROR;
import static br.com.walmart.dashboard.robot.util.Log.log;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.Callable;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import br.com.walmart.dashboard.robot.util.PropertyHandler;

public class EmailService implements Callable<String> {

	private static final Logger logger = LogManager
			.getLogger(EmailService.class);

	private String subject;
	private String content;
	private List<Contato> to;
	private List<Contato> cc;
	private boolean ignoreTemplate;

	public EmailService(String subject, String content,
			List<Contato> to, List<Contato> cc, boolean ignoreTemplate) {
		this.subject = subject;
		this.content = content;
		this.to = to;
		this.cc = cc;
		this.ignoreTemplate = ignoreTemplate;
	}

	@Override
	public String call() throws Exception {
		Properties mailProps = new Properties();
		mailProps.put("mail.smtp.host", PropertyHandler.getInstance().getValue("MAIL_SMTP_HOST"));
		mailProps.put("mail.smtp.port", PropertyHandler.getInstance().getValue("MAIL_SMTP_PORT"));
		mailProps.put("mail.smtp.auth", PropertyHandler.getInstance().getValue("MAIL_SMTP_AUTH"));

		String from = PropertyHandler.getInstance().getValue("MAIL_SMTP_FROM");

		if (to == null) {
			to = new ArrayList<Contato>();
			to.add(new Contato("ROBOT", PropertyHandler.getInstance().getValue("MAIL_SMTP_TO")));
		}

		Session session = null;

		if ("true".equals(PropertyHandler.getInstance().getValue("MAIL_SMTP_AUTH"))) {
			mailProps.put("mail.smtp.starttls.enable",
					PropertyHandler.getInstance().getValue("MAIL_SMTP_START_TLS"));
			mailProps.put("mail.smtp.startssl.enable",
					PropertyHandler.getInstance().getValue("MAIL_SMTP_START_SSL"));

			final String username = PropertyHandler.getInstance().getValue("MAIL_SMTP_USERNAME");
			final String password = PropertyHandler.getInstance().getValue("MAIL_SMTP_PASSWORD");
			session = Session.getInstance(mailProps,
					new javax.mail.Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication() {
							return new PasswordAuthentication(username,
									password);
						}
					});
		} else {
			session = Session.getInstance(mailProps);
		}

		StringBuilder sb = new StringBuilder();

		if (ignoreTemplate) {
			sb.append(String.format(
					"<h1 style='color: #004c91; font-weight: bolder'>%s</h1>",
					subject));
			sb.append(String.format("<span style='color: #f47321'>%s</span>",
					content));
		} else {
			sb.append(content);
		}

		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.setSubject(subject);
			message.setText(sb.toString(), "utf-8", "html");

			int sentinel = 0;
			Address[] toAddresses = new InternetAddress[to.size()];

			for (Contato email : to) {
				toAddresses[sentinel++] = new InternetAddress(email.getEmail());
			}

			if (to != null && !to.isEmpty()) {
				message.addRecipients(Message.RecipientType.TO, toAddresses);
			}

			if (cc != null) {
				sentinel = 0;
				Address[] ccAddresses = new InternetAddress[cc.size()];

				for (Contato email : cc) {
					ccAddresses[sentinel++] = new InternetAddress(
							email.getEmail());
				}

				if (!cc.isEmpty()) {
					message.addRecipients(Message.RecipientType.CC, ccAddresses);
				}
			}

			message.addRecipient(Message.RecipientType.BCC,
					new InternetAddress("br.monitoramento@wal-mart.com"));

			session.setDebug(false);

			Transport.send(message);
		} catch (MessagingException e) {
			log(logger, ERROR, e.getMessage());
		}

		return null;
	}

}
