package br.com.walmart.dashboard.robot.task;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import br.com.walmart.dashboard.robot.connection.RobotConnection;
import br.com.walmart.dashboard.robot.exception.RobotException;
import br.com.walmart.dashboard.robot.util.Controlador;
import br.com.walmart.dashboard.robot.util.MultithreadPing;
import br.com.walmart.dashboard.robot.util.PropertyHandler;
import br.com.walmart.encrypter.Encrypter;

public class PingTask implements Callable<String> {

	@Override
	public String call() throws Exception {
		int nThreads = Integer.valueOf(PropertyHandler.getInstance().getValue(
				"NTHREADS"));
		Map<Integer, List<Controlador>> map = new HashMap<Integer, List<Controlador>>();
		String region = PropertyHandler.getInstance()
				.getValue("REGION_NETWORK");
		Integer sentinel = 0;
		Integer minutes = 0;

		String password = new Encrypter().decrypt(PropertyHandler.getInstance()
				.getValue("MAIN_MSSQL_PWD"));

		Connection mainMSSQL = new RobotConnection().getConnection(
				PropertyHandler.getInstance().getValue("MAIN_MSSQL_DRIVER"),
				PropertyHandler.getInstance().getValue("MAIN_MSSQL_URL"),
				PropertyHandler.getInstance().getValue("MAIN_MSSQL_USER"),
				password);

		StringBuilder field = new StringBuilder("ProximaExecucaoPing");
		if ("SUL".equals(region)) {
			field.append("Sul");
		} else if ("BIG".equals(region)) {
			field.append("Big");
		}

		String sql = String.format(
				"SELECT TmpExecucaoPing, %s FROM ConfigRobo with (nolock) ",
				field.toString());
		PreparedStatement ps = mainMSSQL.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		if (rs.next()) {
		      minutes = Integer.valueOf(rs.getInt(1));
		      Timestamp nextExecution = rs.getTimestamp(2);
		      if (nextExecution != null) {
		        new Date().before(nextExecution);
		      }
		    }

		try {
			long oneMinuteInMillis = 60000;
			long nextExecution = new Date().getTime()
					+ (minutes * oneMinuteInMillis);

			ps = mainMSSQL.prepareStatement(String.format(
					"UPDATE ConfigRobo SET %s = ? ", field.toString()));
			ps.setTimestamp(1, new Timestamp(nextExecution));
			ps.executeUpdate();
		} catch (SQLException sqle) {
			throw new RobotException(sqle.getMessage());
		}

		StringBuilder builder = new StringBuilder(" SELECT DISTINCT ");
		builder.append(" AlertaPadrao.NmAlertaPadrao as NmAlertaPadrao, AlertaPadrao.IdAlertaPadrao as IdAlertaPadrao, ");
		builder.append(" Controlador.CodUnidade as CodUnidade, Controlador.IpComunicacao as IpComunicacao, ");
		builder.append(" UPPER(ModeloFornecedor.Fornecedor) as Fornecedor, ");
		builder.append(" CriticidadeAlerta.TpCriticidade as TpCriticidade, ");
		builder.append(" ModeloFornecedor.Fornecedor ");
		builder.append(" FROM Controlador with (nolock) ");
		builder.append(" INNER JOIN AlertaPadrao with (nolock) ON FlIndicador = 'S' ");
		builder.append(" LEFT JOIN CriticidadeAlerta with (nolock) ON CriticidadeAlerta.IdAlertaPadrao = AlertaPadrao.IdAlertaPadrao ");
		builder.append(" LEFT JOIN ModeloFornecedor with (nolock) ON ModeloFornecedor.IdModeloFornecedor = Controlador.IdModeloFornecedor ");
		builder.append(" INNER JOIN CadastroUnidade ON CadastroUnidade.CodUnidade = Controlador.CodUnidade ");
		builder.append(" WHERE Rede = ? AND CadastroUnidade.Status = 'A' ");

		ps = mainMSSQL.prepareStatement(builder.toString());
		ps.setString(1, region);
		rs = ps.executeQuery();

		while (rs.next()) {
			if (sentinel >= nThreads) {
				sentinel = 0;
			}

			String ip = rs.getString("IpComunicacao");

			if (ip != null) {
				ip = ip.trim();
			}

			Controlador controlador = new Controlador();
			controlador.setNomeAlertaPadrao(rs.getString("NmAlertaPadrao"));
			controlador.setIdAlertaPadrao(rs.getInt("IdAlertaPadrao"));
			controlador.setCodigoUnidade(rs.getInt("CodUnidade"));
			controlador.setIpComunicacao(ip);
			controlador.setFornecedor(rs.getString("Fornecedor"));
			// controlador.setControladorId(rs.getInt("IdControlador"));
			controlador.setCircuito(rs.getString("IpComunicacao"));

			Integer tipoCriticidade = rs.getInt("TpCriticidade");
			if (tipoCriticidade == null) {
				controlador.setTipoCriticidade(0);
			} else {
				controlador.setTipoCriticidade(rs.getInt("TpCriticidade"));
			}

			if (map.containsKey(sentinel)) {
				(map.get(sentinel)).add(controlador);
			} else {
				List<Controlador> c = new ArrayList<Controlador>();
				c.add(controlador);
				map.put(sentinel, c);
			}

			sentinel++;
		}

		if (!map.isEmpty()) {
			ExecutorService executor = Executors.newFixedThreadPool(map.size());
			List<Future<String>> list = new ArrayList<Future<String>>();

			for (Map.Entry<Integer, List<Controlador>> entry : map.entrySet()) {
				MultithreadPing worker = new MultithreadPing();
				worker.setControladores(entry.getValue());
				Future<String> submit = executor.submit(worker);
				list.add(submit);
			}

			try {
				for (Future<String> future : list) {
					future.get();
				}
			} catch (InterruptedException e) {
				new RobotException(e.getMessage());
			} catch (ExecutionException e) {
				new RobotException(e.getMessage());
			} finally {
				executor.shutdown();
			}
		}

		if (mainMSSQL != null) {
			mainMSSQL.close();
			mainMSSQL = null;
		}

		return null;
	}
}
