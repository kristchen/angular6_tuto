package br.com.walmart.dashboard.robot;

import static br.com.walmart.dashboard.robot.util.Log.ERROR;
import static br.com.walmart.dashboard.robot.util.Log.INFO;
import static br.com.walmart.dashboard.robot.util.Log.isDebugMode;
import static br.com.walmart.dashboard.robot.util.Log.log;
import static br.com.walmart.dashboard.robot.util.Log.setDebug;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import br.com.walmart.dashboard.robot.callable.DailyEmailCallable;
import br.com.walmart.dashboard.robot.callable.DanfossCallable;
import br.com.walmart.dashboard.robot.callable.DanfossInvalidCallable;
import br.com.walmart.dashboard.robot.callable.EmersonCallable;
import br.com.walmart.dashboard.robot.callable.HoneywellIscopeCallable;
import br.com.walmart.dashboard.robot.callable.HoneywellOpusCallable;
import br.com.walmart.dashboard.robot.callable.PingCallable;
import br.com.walmart.dashboard.robot.callable.SemaforoCallable;
import br.com.walmart.dashboard.robot.exception.RobotException;
import br.com.walmart.dashboard.robot.util.PropertyHandler;

public class DashboardRobot {

	private static final Logger logger = LogManager
			.getLogger(DashboardRobot.class);

	private List<String> processes = new ArrayList<String>();

	private final String EMERSON = "emerson";
	private final String EMERSON_2 = "emerson2";
	private final String DANFOSS = "danfoss";
	private final String DANFOSS_INVALID = "danfoss_invalid";
	private final String HONEYWELL_OPUS = "honeywell_opus";
	private final String HONEYWELL_ISCOPE = "honeywell_iscope";
	private final String SEMAFORO = "semaforo";
	private final String PING = "ping";
	private final String DAILY_EMAIL = "daily_email";

	public static void main(String[] args) {
		new DashboardRobot().init(args);
	}

	public void init(String[] args) {
		setDebug(Boolean.parseBoolean(PropertyHandler.getInstance().getValue(
				"SHOW_DEBUG")));

		if (isDebugMode()) {
			log(logger, INFO, "Running the debug mode...");
		}

		turnOnOrOffTHeThread();
		// }

		try {
			execute();
		} catch (RobotException e) {
			log(logger, ERROR, e.getMessage());
		}
	}

	private void turnOnOrOffTHeThread() {
		String threadName[] = { EMERSON, EMERSON_2, DANFOSS, DANFOSS_INVALID, HONEYWELL_OPUS,
				HONEYWELL_ISCOPE, SEMAFORO, PING, DAILY_EMAIL };

		for (int i = 0; i < threadName.length; i++) {
			if (Boolean.parseBoolean(PropertyHandler.getInstance().getValue(
					threadName[i].toUpperCase() + "_THREAD"))) {
				processes.add(threadName[i]);
			}
		}
	}

	private void execute() throws RobotException {
		log(logger, INFO, "Executing the threads");

		int nThreads = processes.size();

		if (nThreads == 0) {
			log(logger, ERROR, "There isn't process to execute");
			System.exit(-1);
		}

		log(logger, INFO, "Creating the Thread Pool");
		ExecutorService executor = Executors.newFixedThreadPool(nThreads);

		if (processes.contains(EMERSON)) {
			log(logger, INFO, "Adding a thread to Emerson's controllers");
			Runnable runnable = new EmersonCallable("MSACCESS_FILE");
			executor.submit(runnable);
		}
		
		if (processes.contains(EMERSON_2)) {
			log(logger, INFO, "Adding a thread to Emerson2's controllers");
			Runnable runnable = new EmersonCallable("MSACCESS_FILE_2");
			executor.submit(runnable);
		}
		
		if (processes.contains(DANFOSS)) {
			log(logger, INFO, "Adding a thread to Danfoss' controllers");
			Runnable runnable = new DanfossCallable();
			executor.submit(runnable);
		}
		
		if (processes.contains(DANFOSS_INVALID)) {
			log(logger, INFO, "Adding a thread to Danfoss' Invalid controllers");
			Runnable runnable = new DanfossInvalidCallable();
			executor.submit(runnable);
		}
		
		if (processes.contains(HONEYWELL_OPUS)) {
			log(logger, INFO, "Adding a thread to Honeywell Opus' controllers");
			Runnable runnable = new HoneywellOpusCallable();
			executor.submit(runnable);
		}

		if (processes.contains(HONEYWELL_ISCOPE)) {
			log(logger, INFO,
					"Adding a thread to Honeywell Iscope' controllers");
			Runnable runnable = new HoneywellIscopeCallable();
			executor.submit(runnable);
		}

		if (processes.contains(SEMAFORO)) {
			log(logger, INFO, "Semaforo Callable");
			Runnable runnable = new SemaforoCallable();
			executor.submit(runnable);
		}

		if (processes.contains(PING)) {
			log(logger, INFO, "IP Callable");
			Runnable runnable = new PingCallable();
			executor.submit(runnable);
		}

		if (processes.contains(DAILY_EMAIL)) {
			log(logger, INFO, "Daily Email Callable");
			Runnable runnable = new DailyEmailCallable();
			executor.submit(runnable);
		}
	}
}
