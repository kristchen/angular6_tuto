package br.com.walmart.dashboard.robot.task;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import br.com.walmart.dashboard.robot.exception.RobotException;
import br.com.walmart.dashboard.robot.util.PropertyHandler;
import br.com.walmart.encrypter.Encrypter;

public class HoneywellIscopeTask extends GenericTask {

	private final String FANTASIA = "honeywell-iscope";
	private static final Logger logger = LogManager.getLogger(HoneywellIscopeTask.class); 

	public HoneywellIscopeTask() throws RobotException {
		setFantasia(FANTASIA);
		setFornecedor("honeywell");
	}

	public String call() throws Exception {
		Connection connection = null;

		String driver = null;
		String url = null;
		String user = null;
		String pwd = null;

		logger.info("call() - begin");

		if (connection == null || (connection != null && connection.isClosed())) {
			driver = PropertyHandler.getInstance().getValue(
					"HONEYWELL_ISCOPE_MSSQL_DRIVER");
			url = PropertyHandler.getInstance().getValue(
					"HONEYWELL_ISCOPE_MSSQL_URL");
			user = PropertyHandler.getInstance().getValue(
					"HONEYWELL_ISCOPE_MSSQL_USER");
			pwd = new Encrypter().decrypt(PropertyHandler.getInstance()
					.getValue("HONEYWELL_ISCOPE_MSSQL_PWD"));
			
			try {
				Class.forName(driver);
				connection = DriverManager.getConnection(url, user, pwd);
			} catch (SQLException sqle) {

				closeMainConnection();

				String title = String
						.format("There was error when connect to Honeywell Iscope's MSSQL Server.");
				String description = sqle.toString();

				logger.error("call() - SQLException 1 - " + title + "- " + description);
				throw new RobotException(title + "- " + description);
			}
		}

		StringBuilder sql = null;
		PreparedStatement ps = null;
		ResultSet rsLoop = null;

		try {

			String h = PropertyHandler.getInstance().getValue("ALARM_DURATION");
			if (h == null || "".equals(h)) {
				h = "1";
			}

			// Query para ISCOPE da base IscopeDatabase
//			sql = new StringBuilder(" select [SysNum] as SysNum ");
//			sql.append(" ,[UnitNum] as UnitNum ");
//			sql.append(" ,[MonitorAlarmNum] as MonitorAlarmNum ");
//			sql.append(" ,[SystemName] as SystemName ");
//			sql.append(" ,[UnitName] as UnitName ");
//			sql.append(" ,[MonitorAlarmName] as MonitorAlarmName ");
//			sql.append(" ,[Monitor Alarm Name] as Circuito ");
//			sql.append(" ,[Alarm State] as AlarmState ");
//			sql.append(" ,[Inhibit State] as InhibitState ");
//			sql.append(" ,[Disk Op Mode] as DiskOpMode ");
//			sql.append(" ,[Unit Op Mode] as UnitOpMode ");
//			sql.append(" ,[Remote Report] as RemoteReport ");
//			sql.append(" ,cast([DateTime] as DateTime) as OccurrenceDateTime ");
//			sql.append(" from NBR_AlarmTeste ");
//			sql.append(" WHERE cast([DateTime] as datetime) >= DATEADD(HH, -");
//			sql.append(h);
//			sql.append(" , getdate()) ");
//			sql.append(" and [Alarm State]='Critical' ");
//			sql.append(" ORDER BY OccurrenceDateTime DESC ");

			// Query para ISCOPE da base NovarAlarme
			sql = new StringBuilder(" select System as SysNum ");
			sql.append(" ,SystemName as SystemName ");
			sql.append(" ,UnitName as UnitName ");
			sql.append(" ,AlarmName as MonitorAlarmName ");
			sql.append(" ,AlarmName as Circuito ");
			sql.append(" ,TimeOccurred as OccurrenceDateTime ");
			sql.append(" from NovarAlarms ");
			sql.append(" WHERE TimeOccurred >= DATEADD(HH, -");
			sql.append(h);
			sql.append(" , getdate()) ");
			sql.append(" and TimeOccurred is not null ");
			sql.append(" ORDER BY TimeOccurred DESC ");
			
			ps = connection.prepareStatement(sql.toString());
			rsLoop = ps.executeQuery();
			logger.info("call() - SELECT - " + sql.toString());
			
		} catch (SQLException sqle) {
			if (connection != null) {
				connection.close();
				connection = null;
			}
			closeMainConnection();

			String title = "An error occurring in the main query of the Honeywell Iscope.";
			String description = sqle.toString();

			logger.error("call() - SQLException 2 - " + title + "- " + description);
			throw new Exception(title + "- " + description);
		}

		while (rsLoop.next()) 
		{
			// Test if the connection is opened.
			try {
				connection.createStatement().executeQuery("SELECT 1");
			} catch (SQLException sqle) {
				logger.info("call() - SQLException 3 - connection error " + sqle.toString());
				if (connection != null && !connection.isClosed()) {
					connection.close();
					connection = null;
				}

				break;
			}

			Long currentNum = 0L;
			String unitCode = rsLoop.getString("SysNum");
			String unitName = rsLoop.getString("SystemName");
			String alarmName = rsLoop.getString("MonitorAlarmName");
			Date dataDoAlarme = rsLoop.getTimestamp("OccurrenceDateTime");
			String circuito = rsLoop.getString("Circuito");
			String tipoDoRack = rsLoop.getString("UnitName");

			if (alarmName == null || "".equals(alarmName)) {
				alarmName = circuito;
			}
			
			Integer codUnidade = null;
			try {
				codUnidade = getCodUnidade(unitCode);
			} catch (RobotException e) {
				logger.error("call() - getCodUnidade("+unitCode+") - RobotException - continue ");
				continue;
			}
			
			atualizarDataUltimoEnvioUnidade(codUnidade);
			
			if (checkIfAlarmHasAlreadyBeenInserted(alarmName, unitName,
					circuito, tipoDoRack)) {
				logger.info("call() - checkIfAlarmHasAlreadyBeenInserted - continue ");
				continue;
			}

			if (unitCode == null) {
				String title = "There was error when get 'SystemNumber' value";
				String description = String
						.format("'SystemNum' field is null to Honeywell Iscope's alert #%d",
								currentNum);
				logAndSendEmail(title, description);
				logger.info("call() - unitCode == null - continue ");
				continue;
			}

			Integer alertaPadrao = null;
			try {
				alertaPadrao = getDefaultAlertMessage(alarmName);
			} catch (RobotException e) {
				logger.error("call() - getDefaultAlertMessage("+alarmName+") - RobotException - continue ");
				continue;
			}

			Integer statusAlerta = getSemaforo(alertaPadrao);

			if (statusAlerta == null) {
				statusAlerta = 0;
			}

			try {
				insertAlertaControlador(alarmName, alertaPadrao, codUnidade,
						statusAlerta, dataDoAlarme, currentNum, circuito,
						tipoDoRack, unitName, null);
			} catch (RobotException e) {
				String title = "There was error when inserting the 'AlertaControlador' table";
				String description = e.getMessage();
				logAndSendEmail(title, description);
				logger.error("call() - insertAlertaControlador(parms) - RobotException - continue "+title +" "+ description);
			}
		}

		if (connection != null) {
			connection.close();
			connection = null;
		}

		closeMainConnection();

		logger.info("call() - RETURN FANTASIA "+ FANTASIA);
		return FANTASIA;
	}
}
