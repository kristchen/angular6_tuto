package br.com.walmart.dashboard.robot.email;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.com.walmart.dashboard.robot.email.Contato;

public class TemplateEmail {

	private Integer id;
	private String assunto;
	private String corpo;

	private String codigoUnidade;
	private String codigoLegado;
	private String nomeLoja;
	private String bandeira;
	private Timestamp dataOcorrencia;
	private String tipoAlerta;
	private String chamadoInterno;
	private String chamadoExterno;
	private String regiao;
	private String uf;

	private Map<String, List<Contato>> contatos;

	public TemplateEmail() {
		contatos = new HashMap<String, List<Contato>>();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAssunto() {
		return assunto;
	}

	public void setAssunto(String assunto) {
		this.assunto = assunto;
	}

	public String getCorpo() {
		return corpo;
	}

	public void setCorpo(String corpo) {
		this.corpo = corpo;
	}

	public String getCodigoUnidade() {
		return codigoUnidade;
	}

	public void setCodigoUnidade(String codigoUnidade) {
		this.codigoUnidade = codigoUnidade;
	}

	public String getCodigoLegado() {
		return codigoLegado;
	}

	public void setCodigoLegado(String codigoLegado) {
		this.codigoLegado = codigoLegado;
	}

	public String getNomeLoja() {
		return nomeLoja;
	}

	public void setNomeLoja(String nomeLoja) {
		this.nomeLoja = nomeLoja;
	}

	public String getBandeira() {
		return bandeira;
	}

	public void setBandeira(String bandeira) {
		this.bandeira = bandeira;
	}

	public Timestamp getDataOcorrencia() {
		return dataOcorrencia;
	}

	public void setDataOcorrencia(Timestamp dataOcorrencia) {
		this.dataOcorrencia = dataOcorrencia;
	}

	public String getTipoAlerta() {
		return tipoAlerta;
	}

	public void setTipoAlerta(String tipoAlerta) {
		this.tipoAlerta = tipoAlerta;
	}

	public String getChamadoInterno() {
		return chamadoInterno;
	}

	public void setChamadoInterno(String chamadoInterno) {
		this.chamadoInterno = chamadoInterno;
	}

	public String getChamadoExterno() {
		return chamadoExterno;
	}

	public void setChamadoExterno(String chamadoExterno) {
		this.chamadoExterno = chamadoExterno;
	}

	public String getRegiao() {
		return regiao;
	}

	public void setRegiao(String regiao) {
		this.regiao = regiao;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public Map<String, List<Contato>> getContatos() {
		return contatos;
	}

	public void setContatos(Map<String, List<Contato>> contatos) {
		this.contatos = contatos;
	}

}
