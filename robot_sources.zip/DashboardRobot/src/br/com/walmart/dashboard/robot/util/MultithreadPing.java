package br.com.walmart.dashboard.robot.util;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import br.com.walmart.dashboard.robot.exception.RobotException;
import br.com.walmart.dashboard.robot.task.GenericTask;

public class MultithreadPing extends GenericTask {

	private List<Controlador> controladores;

	public MultithreadPing() throws RobotException {
	}

	public void setControladores(List<Controlador> controladores) {
		this.controladores = controladores;
	}

	public synchronized String call() throws Exception {
		for (Controlador controlador : controladores)  {

			boolean online = false;

			try {
				if (controlador.getIpComunicacao().contains(".")) {
					String cmd = "ping -n 3 " + controlador.getIpComunicacao();
					Process process = Runtime.getRuntime().exec(cmd);
					process.waitFor();
					
					if (process.exitValue() == 0) {
						StringBuilder sql = new StringBuilder(
								" UPDATE Controlador SET Status = 'A' WHERE IpComunicacao = ? ");
						PreparedStatement ps = mainMSSQL
								.prepareStatement(sql.toString());
						ps.setString(1, controlador.getIpComunicacao());
						ps.executeUpdate();
						online = true;

						String sql2 = "SELECT IdAlerta FROM AlertaControlador WHERE Circuito = ? AND StatusAlerta <> 5";
						ps = mainMSSQL.prepareStatement(sql2);
						ps.setString(1, controlador.getIpComunicacao());
						ResultSet rs2 = ps.executeQuery();
						Long idAlerta = null;

						if (rs2.next()) {
							idAlerta = rs2.getLong("IdAlerta");
						}

						if (idAlerta != null) {
							sql2 = "INSERT INTO AlertaControladorDetalhe VALUES (?, "
									+ " 'Alarme encerrado pelo sistema.', GETDATE(), 2, 'N', null, null, 'ROBOT')";
							ps = mainMSSQL.prepareStatement(sql2);
							ps.setLong(1, idAlerta);
							ps.executeUpdate();

							sql2 = "update AlertaControlador set StatusAlerta = 5 where IdAlerta = ? ";
							ps = mainMSSQL.prepareStatement(sql2);
							ps.setLong(1, idAlerta);
							ps.executeUpdate();
						}
					}
				}
			} catch (SQLException sqle) {
				String title = "An error occurring in the main query of the MultithreadedPing";
				String description = sqle.toString();

				throw new RobotException(title + " - " + description);
			}

			if (!online) {
				try {
					// Has this alarm already been inserted?
					int count = 0;

					PreparedStatement ps = mainMSSQL
							.prepareStatement("SELECT count(1) as c FROM AlertaControlador WHERE "
									+ " Circuito = ? AND StatusAlerta <> 5");
					ps.setString(1, controlador.getCircuito());

					ResultSet rsCount = ps.executeQuery();
					if (rsCount.next()) {
						count = rsCount.getInt("c");
					}
					// ------- 06/07/2018
					String sql = " UPDATE Controlador SET Status = 'I' WHERE IpComunicacao = ? ";
					ps = mainMSSQL.prepareStatement(sql.toString());
					ps.setString(1, controlador.getIpComunicacao());
					ps.executeUpdate();
					//---------------------------

					if (count == 0) {
						insertAlertaControlador(
								controlador.getNomeAlertaPadrao(),
								controlador.getIdAlertaPadrao(),
								controlador.getCodigoUnidade(),
								controlador.getTipoCriticidade(),
								new Timestamp(new Date().getTime()), null,
								controlador.getCircuito(), null, null, controlador.getFornecedor(), "");
					}
				} catch (RobotException e) {
					mainMSSQL.createStatement().execute("ROLLBACK");

					String title = "There was error when inserting the 'AlertaControlador' table";
					String description = e.getMessage();
					logAndSendEmail(title, description);
				}
			}
		}

		closeMainConnection();

		return null;
	}
}
