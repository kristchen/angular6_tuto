package br.com.walmart.dashboard.robot.exception;

public class RobotException extends Exception {

	static final long serialVersionUID = -851302435323297758L;

	public RobotException() {
		super();
	}

	public RobotException(String message) {
		super(message);
	}

	public RobotException(String message, Throwable cause) {
		super(message, cause);
	}

	public RobotException(Throwable cause) {
		super(cause);
	}

}
