package br.com.walmart.dashboard.robot.connection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class RobotConnection {

	private Connection connection;

	public RobotConnection() {
		// :~
	}

	public Connection getConnection(String driver, String url, String user,
			String pwd) throws IOException, ClassNotFoundException,
			SQLException {

		if (this.connection == null) {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, pwd);
		}

		return connection;
	}

}
