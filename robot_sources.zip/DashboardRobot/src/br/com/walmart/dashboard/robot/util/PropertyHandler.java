package br.com.walmart.dashboard.robot.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PropertyHandler {

	private static Logger logger = LogManager.getLogger(PropertyHandler.class);
	private static PropertyHandler instance = null;
	private Properties props = null;

	private PropertyHandler() throws IOException {
		InputStream input = new FileInputStream(
				"/Apps/Dashboard/config_big.properties");
		this.props = new Properties();
		this.props.load(input);
	}

	public static synchronized PropertyHandler getInstance() {
		if (instance == null) {
			try {
				instance = new PropertyHandler();
			} catch (IOException e) {
				logger.error("File was not loaded: " + e.getMessage());
			}
		}

		return instance;
	}

	public String getValue(String propKey) {
		return this.props.getProperty(propKey);
	}
}
