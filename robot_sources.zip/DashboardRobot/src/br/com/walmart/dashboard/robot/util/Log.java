package br.com.walmart.dashboard.robot.util;

import org.apache.logging.log4j.Logger;

public class Log {

	public final static String INFO = "info";
	public final static String ERROR = "error";
	public final static String WARN = "warn";

	private static boolean debugMode = false;

	public static void setDebug(boolean debugMode) {
		Log.debugMode = debugMode;
	}

	public static boolean isDebugMode() {
		return debugMode;
	}

	public static void log(Logger logger, String type, String msg) {
		if (debugMode) {
			switch (type) {
			case Log.INFO:
				logger.info(msg);
				break;
			case Log.ERROR:
				logger.error(msg);
				break;
			case Log.WARN:
				logger.warn(msg);
				break;
			default:
				break;
			}
		}
	}

}
